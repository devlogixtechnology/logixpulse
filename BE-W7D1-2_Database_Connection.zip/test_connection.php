<?php
/**
 * Temporary acceptance test for BE-W7D1-2.
 * Upload/run this only on the VPS after db.php has real credentials.
 * Delete it after verification if the project does not need it.
 */

declare(strict_types=1);

require_once __DIR__ . '/db.php';

try {
    $result = $conn->query("SELECT * FROM `users` LIMIT 1");

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        header('Content-Type: text/plain; charset=utf-8');
        echo "SUCCESS: Database connection works and a row was read from users.\n";
        echo "Columns returned: " . implode(', ', array_keys($row)) . "\n";
    } else {
        header('Content-Type: text/plain; charset=utf-8');
        echo "SUCCESS: Database connection works, but the users table has no rows.\n";
    }
} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "FAILED: " . $e->getMessage();
}
?>
