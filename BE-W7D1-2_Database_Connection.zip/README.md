# BE-W7D1-2 — Build the Database Connection File

## Files
- `db.php` — the single shared MySQL/MariaDB connection file.
- `test_connection.php` — acceptance test that includes `db.php` and reads one row from `users`.

## Setup
1. Open `db.php`.
2. Replace:
   - `YOUR_VPS_DB_HOST`
   - `YOUR_DATABASE_NAME`
   - `YOUR_DATABASE_USER`
   - `YOUR_DATABASE_PASSWORD`
3. Keep port `3306` unless the VPS/database team gave a different MySQL/MariaDB port.
4. Upload `db.php` to the PHP project.
5. Any PHP file that needs the database should use:
   `require_once __DIR__ . '/db.php';`
6. Run `test_connection.php` on the VPS to verify the acceptance criterion.
7. Do not publish real database credentials in GitHub or any public/shared repository.

## Important
The actual VPS host, database name, username and password were not included in the task screenshots. The placeholders must be replaced with the real credentials before the test can pass.
